"""VRML97-specific customisations and support

Includes a full VRML97 parser and lineariser
for SimpleParse 2.0.x
"""

